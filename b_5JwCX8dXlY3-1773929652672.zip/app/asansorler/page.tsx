import { DashboardLayout } from "@/components/dashboard-layout"
import { ElevatorList } from "@/components/elevators/elevator-list"

export default function ElevatorsPage() {
  return (
    <DashboardLayout
      title="Asansörler"
      description="Tüm asansörleri görüntüleyin ve yönetin"
    >
      <ElevatorList />
    </DashboardLayout>
  )
}
