import { DashboardLayout } from "@/components/dashboard-layout"
import { MaintenanceList } from "@/components/maintenance/maintenance-list"

export default function MaintenancePage() {
  return (
    <DashboardLayout
      title="Bakımlar"
      description="Planlı bakımları görüntüleyin ve yönetin"
    >
      <MaintenanceList />
    </DashboardLayout>
  )
}
