import { DashboardLayout } from "@/components/dashboard-layout"
import { KpiCards } from "@/components/dashboard/kpi-cards"
import { RecentMaintenance } from "@/components/dashboard/recent-maintenance"
import { RecentFaults } from "@/components/dashboard/recent-faults"

export default function DashboardPage() {
  return (
    <DashboardLayout
      title="Dashboard"
      description="Arlift Asansör yönetim paneline hoş geldiniz"
    >
      <div className="space-y-6">
        <KpiCards />
        
        <div className="grid gap-6 lg:grid-cols-2">
          <RecentMaintenance />
          <RecentFaults />
        </div>
      </div>
    </DashboardLayout>
  )
}
