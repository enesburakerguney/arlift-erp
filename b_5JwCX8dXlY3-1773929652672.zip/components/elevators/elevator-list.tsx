"use client"

import { useState } from "react"
import { Search, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { InputGroup, InputGroupInput, InputGroupAddon } from "@/components/ui/input-group"

const elevatorsData = [
  {
    id: "ASN-0001",
    brand: "KONE",
    building: "Yeşil Vadi Sitesi A Blok",
    customer: "Yeşil Vadi Site Yönetimi",
    status: "aktif",
    label: "yesil",
    lastMaintenance: "15 Mar 2026",
    capacity: "630 kg",
    floors: 8,
  },
  {
    id: "ASN-0042",
    brand: "Otis",
    building: "Yeşil Vadi Sitesi A Blok",
    customer: "Yeşil Vadi Site Yönetimi",
    status: "aktif",
    label: "sari",
    lastMaintenance: "18 Mar 2026",
    capacity: "800 kg",
    floors: 10,
  },
  {
    id: "ASN-0078",
    brand: "ThyssenKrupp",
    building: "Deniz Sitesi B Blok",
    customer: "Deniz Sitesi Yönetimi",
    status: "aktif",
    label: "yesil",
    lastMaintenance: "10 Mar 2026",
    capacity: "630 kg",
    floors: 6,
  },
  {
    id: "ASN-0089",
    brand: "Schindler",
    building: "Koza Plaza",
    customer: "Koza Plaza A.Ş.",
    status: "aktif",
    label: "mavi",
    lastMaintenance: "17 Mar 2026",
    capacity: "1000 kg",
    floors: 15,
  },
  {
    id: "ASN-0156",
    brand: "KONE",
    building: "Güneş Apt.",
    customer: "Güneş Apartmanı",
    status: "pasif",
    label: "kirmizi",
    lastMaintenance: "01 Mar 2026",
    capacity: "450 kg",
    floors: 5,
  },
  {
    id: "ASN-0201",
    brand: "Mitsubishi",
    building: "Merkez İş Hanı",
    customer: "Merkez İş Hanı",
    status: "aktif",
    label: "turuncu",
    lastMaintenance: "12 Mar 2026",
    capacity: "1200 kg",
    floors: 12,
  },
  {
    id: "ASN-0215",
    brand: "Otis",
    building: "Mavi Köşk Sitesi A Blok",
    customer: "Mavi Köşk Sitesi",
    status: "aktif",
    label: "yesil",
    lastMaintenance: "14 Mar 2026",
    capacity: "630 kg",
    floors: 7,
  },
  {
    id: "ASN-0248",
    brand: "KONE",
    building: "Çınar Residence",
    customer: "Çınar Residence",
    status: "aktif",
    label: "mavi",
    lastMaintenance: "16 Mar 2026",
    capacity: "800 kg",
    floors: 9,
  },
]

const statusConfig: Record<string, { label: string; className: string }> = {
  aktif: { label: "Aktif", className: "bg-chart-2/10 text-chart-2" },
  pasif: { label: "Pasif", className: "bg-muted text-muted-foreground" },
}

const labelConfig: Record<string, { label: string; color: string }> = {
  yesil: { label: "Yeşil", color: "bg-green-500" },
  sari: { label: "Sarı", color: "bg-yellow-500" },
  kirmizi: { label: "Kırmızı", color: "bg-red-500" },
  mavi: { label: "Mavi", color: "bg-blue-500" },
  turuncu: { label: "Turuncu", color: "bg-orange-500" },
}

export function ElevatorList() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [labelFilter, setLabelFilter] = useState<string>("all")

  const filteredElevators = elevatorsData.filter((elevator) => {
    const matchesSearch =
      elevator.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      elevator.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      elevator.building.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus =
      statusFilter === "all" || elevator.status === statusFilter
    const matchesLabel = labelFilter === "all" || elevator.label === labelFilter

    return matchesSearch && matchesStatus && matchesLabel
  })

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <InputGroup className="max-w-sm">
          <InputGroupAddon>
            <Search className="h-4 w-4 text-muted-foreground" />
          </InputGroupAddon>
          <InputGroupInput
            placeholder="Asansör ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </InputGroup>

        <div className="flex flex-wrap items-center gap-3">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Durum" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tüm Durumlar</SelectItem>
              <SelectItem value="aktif">Aktif</SelectItem>
              <SelectItem value="pasif">Pasif</SelectItem>
            </SelectContent>
          </Select>

          <Select value={labelFilter} onValueChange={setLabelFilter}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Etiket" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tüm Etiketler</SelectItem>
              <SelectItem value="yesil">Yeşil</SelectItem>
              <SelectItem value="sari">Sarı</SelectItem>
              <SelectItem value="kirmizi">Kırmızı</SelectItem>
              <SelectItem value="mavi">Mavi</SelectItem>
              <SelectItem value="turuncu">Turuncu</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Table */}
      <Card className="border-border/50 shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Asansör ID</TableHead>
                <TableHead>Marka</TableHead>
                <TableHead className="hidden md:table-cell">Bina</TableHead>
                <TableHead className="hidden lg:table-cell">Kapasite</TableHead>
                <TableHead>Durum</TableHead>
                <TableHead>Etiket</TableHead>
                <TableHead className="hidden md:table-cell">Son Bakım</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredElevators.map((elevator) => (
                <TableRow key={elevator.id} className="cursor-pointer hover:bg-muted/50">
                  <TableCell className="font-medium">{elevator.id}</TableCell>
                  <TableCell>{elevator.brand}</TableCell>
                  <TableCell className="hidden md:table-cell">
                    <div>
                      <p>{elevator.building}</p>
                      <p className="text-xs text-muted-foreground">
                        {elevator.floors} kat
                      </p>
                    </div>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell">
                    {elevator.capacity}
                  </TableCell>
                  <TableCell>
                    <Badge className={statusConfig[elevator.status].className}>
                      {statusConfig[elevator.status].label}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div
                        className={`h-3 w-3 rounded-full ${labelConfig[elevator.label].color}`}
                      />
                      <span className="hidden text-sm sm:inline">
                        {labelConfig[elevator.label].label}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    {elevator.lastMaintenance}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {filteredElevators.length === 0 && (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-12">
          <Filter className="h-12 w-12 text-muted-foreground/50" />
          <p className="mt-4 text-lg font-medium text-muted-foreground">
            Asansör bulunamadı
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Filtrelerinizi değiştirmeyi deneyin
          </p>
        </div>
      )}
    </div>
  )
}
