"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import {
  LayoutDashboard,
  Users,
  Building2,
  ArrowUpDown,
  Wrench,
  AlertTriangle,
  Calculator,
  FileBarChart,
  Menu,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const menuItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/musteriler", label: "Müşteriler", icon: Users },
  { href: "/binalar", label: "Binalar", icon: Building2 },
  { href: "/asansorler", label: "Asansörler", icon: ArrowUpDown },
  { href: "/bakimlar", label: "Bakımlar", icon: Wrench },
  { href: "/arizalar", label: "Arızalar", icon: AlertTriangle },
  { href: "/muhasebe", label: "Muhasebe", icon: Calculator },
  { href: "/raporlar", label: "Raporlar", icon: FileBarChart },
]

export function MobileNav() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  return (
    <div className="fixed left-0 right-0 top-0 z-50 flex h-14 items-center justify-between border-b border-border bg-card px-4 lg:hidden">
      <Link href="/" className="flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
          <ArrowUpDown className="h-4 w-4 text-primary-foreground" />
        </div>
        <span className="text-lg font-bold text-foreground">Arlift</span>
      </Link>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Menüyü aç</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-72 bg-sidebar p-0 text-sidebar-foreground">
          <div className="flex h-full flex-col">
            {/* Logo */}
            <div className="flex h-16 items-center gap-2 border-b border-sidebar-border px-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-sidebar-foreground">
                <ArrowUpDown className="h-5 w-5 text-sidebar" />
              </div>
              <span className="text-xl font-bold">Arlift</span>
            </div>

            {/* Navigation */}
            <nav className="flex-1 space-y-1 px-3 py-4">
              {menuItems.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                      isActive
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                    )}
                  >
                    <item.icon className="h-5 w-5 shrink-0" />
                    <span>{item.label}</span>
                  </Link>
                )
              })}
            </nav>

            {/* User Profile */}
            <div className="border-t border-sidebar-border p-4">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10 border-2 border-sidebar-accent">
                  <AvatarImage src="/placeholder-user.jpg" alt="User" />
                  <AvatarFallback className="bg-sidebar-accent text-sidebar-accent-foreground">
                    AK
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 overflow-hidden">
                  <p className="truncate text-sm font-medium">Ahmet Kaya</p>
                  <Badge
                    variant="secondary"
                    className="mt-1 bg-sidebar-accent text-sidebar-accent-foreground text-xs"
                  >
                    Yönetici
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
