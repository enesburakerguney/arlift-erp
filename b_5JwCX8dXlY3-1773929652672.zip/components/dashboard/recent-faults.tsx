import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Clock } from "lucide-react"

const faultsData = [
  {
    id: "ARZ-0089",
    elevator: "ASN-0042",
    building: "Yeşil Vadi Sitesi A Blok",
    description: "Kapı sensörü arızası",
    priority: "acil",
    createdAt: "2 saat önce",
  },
  {
    id: "ARZ-0088",
    elevator: "ASN-0156",
    building: "Güneş Apt.",
    description: "Düğme paneli yanmıyor",
    priority: "yuksek",
    createdAt: "5 saat önce",
  },
  {
    id: "ARZ-0087",
    elevator: "ASN-0201",
    building: "Merkez İş Hanı",
    description: "Aşırı gürültü şikayeti",
    priority: "normal",
    createdAt: "1 gün önce",
  },
  {
    id: "ARZ-0086",
    elevator: "ASN-0078",
    building: "Deniz Sitesi B Blok",
    description: "Kat göstergesi çalışmıyor",
    priority: "normal",
    createdAt: "1 gün önce",
  },
  {
    id: "ARZ-0085",
    elevator: "ASN-0089",
    building: "Koza Plaza",
    description: "Acil durum butonu testi",
    priority: "yuksek",
    createdAt: "2 gün önce",
  },
]

const priorityConfig: Record<string, { label: string; className: string }> = {
  acil: { label: "Acil", className: "bg-destructive/10 text-destructive hover:bg-destructive/20" },
  yuksek: { label: "Yüksek", className: "bg-chart-3/10 text-chart-3 hover:bg-chart-3/20" },
  normal: { label: "Normal", className: "bg-primary/10 text-primary hover:bg-primary/20" },
}

export function RecentFaults() {
  return (
    <Card className="border-border/50 shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Açık Arızalar</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {faultsData.map((fault) => (
            <div
              key={fault.id}
              className="flex items-start gap-4 rounded-lg border border-border/50 p-4 transition-colors hover:bg-muted/50"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-destructive/10">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-medium text-foreground">{fault.description}</p>
                  <Badge className={priorityConfig[fault.priority].className}>
                    {priorityConfig[fault.priority].label}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {fault.elevator} - {fault.building}
                </p>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span>{fault.createdAt}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
