import { ArrowUpDown, Wrench, AlertTriangle, TrendingUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const kpiData = [
  {
    title: "Toplam Asansör",
    value: "248",
    change: "+12 bu ay",
    icon: ArrowUpDown,
    iconBg: "bg-primary/10",
    iconColor: "text-primary",
  },
  {
    title: "Bekleyen Bakım",
    value: "34",
    change: "7 gün içinde",
    icon: Wrench,
    iconBg: "bg-chart-3/10",
    iconColor: "text-chart-3",
  },
  {
    title: "Açık Arıza",
    value: "8",
    change: "3 acil",
    icon: AlertTriangle,
    iconBg: "bg-destructive/10",
    iconColor: "text-destructive",
  },
  {
    title: "Aylık Gelir",
    value: "₺124.500",
    change: "+8.2% geçen aya göre",
    icon: TrendingUp,
    iconBg: "bg-chart-2/10",
    iconColor: "text-chart-2",
  },
]

export function KpiCards() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {kpiData.map((kpi) => (
        <Card key={kpi.title} className="border-border/50 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {kpi.title}
            </CardTitle>
            <div className={`rounded-lg p-2 ${kpi.iconBg}`}>
              <kpi.icon className={`h-4 w-4 ${kpi.iconColor}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{kpi.value}</div>
            <p className="mt-1 text-xs text-muted-foreground">{kpi.change}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
