import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

const maintenanceData = [
  {
    id: "BKM-0124",
    elevator: "ASN-0042",
    building: "Yeşil Vadi Sitesi A Blok",
    technician: "Mehmet Yılmaz",
    date: "18 Mar 2026",
    status: "yapildi",
  },
  {
    id: "BKM-0123",
    elevator: "ASN-0089",
    building: "Koza Plaza",
    technician: "Ali Demir",
    date: "17 Mar 2026",
    status: "yapildi",
  },
  {
    id: "BKM-0122",
    elevator: "ASN-0156",
    building: "Güneş Apt.",
    technician: "Ahmet Kaya",
    date: "19 Mar 2026",
    status: "bekliyor",
  },
  {
    id: "BKM-0121",
    elevator: "ASN-0078",
    building: "Deniz Sitesi B Blok",
    technician: "Mehmet Yılmaz",
    date: "20 Mar 2026",
    status: "bekliyor",
  },
  {
    id: "BKM-0120",
    elevator: "ASN-0201",
    building: "Merkez İş Hanı",
    technician: "Ali Demir",
    date: "16 Mar 2026",
    status: "iptal",
  },
]

const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  yapildi: { label: "Yapıldı", variant: "default" },
  bekliyor: { label: "Bekliyor", variant: "secondary" },
  iptal: { label: "İptal", variant: "destructive" },
}

export function RecentMaintenance() {
  return (
    <Card className="border-border/50 shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Son Bakımlar</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Asansör</TableHead>
              <TableHead className="hidden md:table-cell">Bina</TableHead>
              <TableHead className="hidden lg:table-cell">Teknisyen</TableHead>
              <TableHead>Tarih</TableHead>
              <TableHead>Durum</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {maintenanceData.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">{item.elevator}</TableCell>
                <TableCell className="hidden md:table-cell">{item.building}</TableCell>
                <TableCell className="hidden lg:table-cell">{item.technician}</TableCell>
                <TableCell>{item.date}</TableCell>
                <TableCell>
                  <Badge
                    variant={statusConfig[item.status].variant}
                    className={
                      item.status === "yapildi"
                        ? "bg-chart-2/10 text-chart-2 hover:bg-chart-2/20"
                        : item.status === "bekliyor"
                        ? "bg-chart-3/10 text-chart-3 hover:bg-chart-3/20"
                        : ""
                    }
                  >
                    {statusConfig[item.status].label}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
