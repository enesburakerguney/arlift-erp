"use client"

import { useState } from "react"
import { Calendar, User, Building2, Wrench, Filter } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const maintenanceData = [
  {
    id: "BKM-0130",
    elevator: "ASN-0001",
    building: "Yeşil Vadi Sitesi A Blok",
    customer: "Yeşil Vadi Site Yönetimi",
    plannedDate: "25 Mar 2026",
    technician: "Mehmet Yılmaz",
    status: "bekliyor",
    type: "Periyodik Bakım",
  },
  {
    id: "BKM-0129",
    elevator: "ASN-0089",
    building: "Koza Plaza",
    customer: "Koza Plaza A.Ş.",
    plannedDate: "24 Mar 2026",
    technician: "Ali Demir",
    status: "bekliyor",
    type: "Periyodik Bakım",
  },
  {
    id: "BKM-0128",
    elevator: "ASN-0215",
    building: "Mavi Köşk Sitesi A Blok",
    customer: "Mavi Köşk Sitesi",
    plannedDate: "23 Mar 2026",
    technician: "Ahmet Kaya",
    status: "bekliyor",
    type: "Yıllık Kontrol",
  },
  {
    id: "BKM-0127",
    elevator: "ASN-0078",
    building: "Deniz Sitesi B Blok",
    customer: "Deniz Sitesi Yönetimi",
    plannedDate: "22 Mar 2026",
    technician: "Mehmet Yılmaz",
    status: "bekliyor",
    type: "Periyodik Bakım",
  },
  {
    id: "BKM-0126",
    elevator: "ASN-0042",
    building: "Yeşil Vadi Sitesi A Blok",
    customer: "Yeşil Vadi Site Yönetimi",
    plannedDate: "18 Mar 2026",
    technician: "Mehmet Yılmaz",
    status: "yapildi",
    type: "Periyodik Bakım",
  },
  {
    id: "BKM-0125",
    elevator: "ASN-0248",
    building: "Çınar Residence",
    customer: "Çınar Residence",
    plannedDate: "17 Mar 2026",
    technician: "Ali Demir",
    status: "yapildi",
    type: "Periyodik Bakım",
  },
  {
    id: "BKM-0124",
    elevator: "ASN-0201",
    building: "Merkez İş Hanı",
    customer: "Merkez İş Hanı",
    plannedDate: "16 Mar 2026",
    technician: "Ali Demir",
    status: "iptal",
    type: "Periyodik Bakım",
  },
  {
    id: "BKM-0123",
    elevator: "ASN-0156",
    building: "Güneş Apt.",
    customer: "Güneş Apartmanı",
    plannedDate: "15 Mar 2026",
    technician: "Ahmet Kaya",
    status: "yapildi",
    type: "Arıza Giderimi",
  },
]

const technicians = [
  { value: "all", label: "Tüm Teknisyenler" },
  { value: "mehmet", label: "Mehmet Yılmaz" },
  { value: "ali", label: "Ali Demir" },
  { value: "ahmet", label: "Ahmet Kaya" },
]

const months = [
  { value: "all", label: "Tüm Aylar" },
  { value: "mart", label: "Mart 2026" },
  { value: "nisan", label: "Nisan 2026" },
  { value: "mayis", label: "Mayıs 2026" },
]

const statusConfig: Record<string, { label: string; className: string }> = {
  bekliyor: { label: "Bekliyor", className: "bg-chart-3/10 text-chart-3" },
  yapildi: { label: "Yapıldı", className: "bg-chart-2/10 text-chart-2" },
  iptal: { label: "İptal", className: "bg-destructive/10 text-destructive" },
}

export function MaintenanceList() {
  const [technicianFilter, setTechnicianFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [monthFilter, setMonthFilter] = useState("all")

  const filteredMaintenance = maintenanceData.filter((item) => {
    const matchesTechnician =
      technicianFilter === "all" ||
      (technicianFilter === "mehmet" && item.technician === "Mehmet Yılmaz") ||
      (technicianFilter === "ali" && item.technician === "Ali Demir") ||
      (technicianFilter === "ahmet" && item.technician === "Ahmet Kaya")

    const matchesStatus =
      statusFilter === "all" || item.status === statusFilter

    return matchesTechnician && matchesStatus
  })

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <Select value={technicianFilter} onValueChange={setTechnicianFilter}>
          <SelectTrigger className="w-[180px]">
            <User className="mr-2 h-4 w-4 text-muted-foreground" />
            <SelectValue placeholder="Teknisyen" />
          </SelectTrigger>
          <SelectContent>
            {technicians.map((tech) => (
              <SelectItem key={tech.value} value={tech.value}>
                {tech.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]">
            <Wrench className="mr-2 h-4 w-4 text-muted-foreground" />
            <SelectValue placeholder="Durum" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tüm Durumlar</SelectItem>
            <SelectItem value="bekliyor">Bekliyor</SelectItem>
            <SelectItem value="yapildi">Yapıldı</SelectItem>
            <SelectItem value="iptal">İptal</SelectItem>
          </SelectContent>
        </Select>

        <Select value={monthFilter} onValueChange={setMonthFilter}>
          <SelectTrigger className="w-[160px]">
            <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
            <SelectValue placeholder="Ay" />
          </SelectTrigger>
          <SelectContent>
            {months.map((month) => (
              <SelectItem key={month.value} value={month.value}>
                {month.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Maintenance List */}
      <div className="space-y-3">
        {filteredMaintenance.map((item) => (
          <Card
            key={item.id}
            className="border-border/50 shadow-sm transition-all hover:shadow-md"
          >
            <CardContent className="p-4">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <Wrench className="h-6 w-6 text-primary" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-semibold text-foreground">
                        {item.elevator}
                      </h3>
                      <span className="text-sm text-muted-foreground">
                        {item.id}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                      <Building2 className="h-4 w-4" />
                      <span>{item.building}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{item.type}</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 sm:flex-nowrap">
                  <div className="text-sm">
                    <p className="text-muted-foreground">Teknisyen</p>
                    <p className="font-medium text-foreground">{item.technician}</p>
                  </div>
                  <div className="text-sm">
                    <p className="text-muted-foreground">Planlanan Tarih</p>
                    <p className="font-medium text-foreground">{item.plannedDate}</p>
                  </div>
                  <Badge className={statusConfig[item.status].className}>
                    {statusConfig[item.status].label}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredMaintenance.length === 0 && (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-12">
          <Filter className="h-12 w-12 text-muted-foreground/50" />
          <p className="mt-4 text-lg font-medium text-muted-foreground">
            Bakım kaydı bulunamadı
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Filtrelerinizi değiştirmeyi deneyin
          </p>
        </div>
      )}
    </div>
  )
}
