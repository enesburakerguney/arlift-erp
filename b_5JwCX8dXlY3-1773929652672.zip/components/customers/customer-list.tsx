"use client"

import { useState } from "react"
import { Search, Plus, Phone, Mail, Building2, Elevator } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { InputGroup, InputGroupInput, InputGroupAddon } from "@/components/ui/input-group"

const customersData = [
  {
    id: "MUS-0001",
    title: "Yeşil Vadi Site Yönetimi",
    type: "site",
    contact: "Mustafa Öztürk",
    phone: "0532 123 4567",
    email: "yonetim@yesilvadisite.com",
    elevatorCount: 12,
    buildingCount: 4,
  },
  {
    id: "MUS-0002",
    title: "Koza Plaza A.Ş.",
    type: "isyeri",
    contact: "Ayşe Yılmaz",
    phone: "0212 555 6789",
    email: "teknik@kozaplaza.com.tr",
    elevatorCount: 8,
    buildingCount: 1,
  },
  {
    id: "MUS-0003",
    title: "Güneş Apartmanı",
    type: "apartman",
    contact: "Ahmet Demir",
    phone: "0533 987 6543",
    email: "ahmet.demir@email.com",
    elevatorCount: 2,
    buildingCount: 1,
  },
  {
    id: "MUS-0004",
    title: "Deniz Sitesi Yönetimi",
    type: "site",
    contact: "Fatma Kaya",
    phone: "0535 111 2233",
    email: "denizsitesi@gmail.com",
    elevatorCount: 6,
    buildingCount: 2,
  },
  {
    id: "MUS-0005",
    title: "Merkez İş Hanı",
    type: "isyeri",
    contact: "Hasan Çelik",
    phone: "0212 333 4444",
    email: "info@merkez-ishani.com",
    elevatorCount: 4,
    buildingCount: 1,
  },
  {
    id: "MUS-0006",
    title: "Yıldız Apartmanı",
    type: "apartman",
    contact: "Zeynep Arslan",
    phone: "0536 222 3344",
    email: "zeynep.arslan@email.com",
    elevatorCount: 1,
    buildingCount: 1,
  },
  {
    id: "MUS-0007",
    title: "Mavi Köşk Sitesi",
    type: "site",
    contact: "Osman Yıldırım",
    phone: "0537 444 5566",
    email: "mavikosksite@gmail.com",
    elevatorCount: 9,
    buildingCount: 3,
  },
  {
    id: "MUS-0008",
    title: "Çınar Residence",
    type: "diger",
    contact: "Elif Şahin",
    phone: "0538 666 7788",
    email: "yonetim@cinarresidence.com",
    elevatorCount: 5,
    buildingCount: 1,
  },
]

const typeConfig: Record<string, { label: string; className: string }> = {
  apartman: { label: "Apartman", className: "bg-primary/10 text-primary" },
  site: { label: "Site", className: "bg-chart-2/10 text-chart-2" },
  isyeri: { label: "İşyeri", className: "bg-chart-3/10 text-chart-3" },
  diger: { label: "Diğer", className: "bg-muted text-muted-foreground" },
}

export function CustomerList() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredCustomers = customersData.filter(
    (customer) =>
      customer.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.contact.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Search and Actions */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <InputGroup className="max-w-sm">
          <InputGroupAddon>
            <Search className="h-4 w-4 text-muted-foreground" />
          </InputGroupAddon>
          <InputGroupInput
            placeholder="Müşteri ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </InputGroup>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="mr-2 h-4 w-4" />
          Yeni Müşteri
        </Button>
      </div>

      {/* Customer Grid */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {filteredCustomers.map((customer) => (
          <Card
            key={customer.id}
            className="border-border/50 shadow-sm transition-shadow hover:shadow-md"
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-xs font-medium text-muted-foreground">
                    {customer.id}
                  </p>
                  <h3 className="mt-1 font-semibold text-foreground">
                    {customer.title}
                  </h3>
                </div>
                <Badge className={typeConfig[customer.type].className}>
                  {typeConfig[customer.type].label}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p className="font-medium text-foreground">{customer.contact}</p>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  <span>{customer.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span className="truncate">{customer.email}</span>
                </div>
              </div>

              <div className="flex items-center gap-4 border-t border-border/50 pt-3 text-sm">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Building2 className="h-4 w-4" />
                  <span>{customer.buildingCount} Bina</span>
                </div>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Elevator className="h-4 w-4" />
                  <span>{customer.elevatorCount} Asansör</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCustomers.length === 0 && (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-12">
          <Search className="h-12 w-12 text-muted-foreground/50" />
          <p className="mt-4 text-lg font-medium text-muted-foreground">
            Müşteri bulunamadı
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Farklı bir arama terimi deneyin
          </p>
        </div>
      )}
    </div>
  )
}
